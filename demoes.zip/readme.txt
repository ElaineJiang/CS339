
Chapter 1:  Introduction to Computer Networking
	Layering Model:    osistack.swf
	Multiplexing:  TDM.htm, ATDM.htm, FDM.htm, CDMA.mht
	Switching: packetSwitching.swf, VirtualCircuit.swf
	Message Segmentation and Delay:  http://media.pearsoncmg.com/aw/aw_kurose_network_2/applets/message/messagesegmentation.html 
	Queuing and packet loss:    http://media.pearsoncmg.com/aw/aw_kurose_network_2/applets/queuing/queuing.html
	Transmission vs. Propagation Delay:   http://media.pearsoncmg.com/aw/aw_kurose_network_2/applets/transmission/delay.html

Chapter2: Application Layer
	Evolution of the Web:  http://www.evolutionoftheweb.com

Chapter3: Transport Layer
	CRC:  CRC.swf
	Go-Back_N protocol: http://media.pearsoncmg.com/aw/aw_kurose_network_4/applets/go-back-n/index.html
	Selective Repeat Protocol:  http://media.pearsoncmg.com/aw/aw_kurose_network_4/applets/SR/index.html 
	TCP Connection Release: TCP ConnectionRelease.swf
	TCP Flow Control: TCP FlowControl.swf
	TCP Congestion Control: http://media.pearsoncmg.com/aw/aw_kurose_network_4/applets/fairness/index.html 

Chapter4: Network Layer
	Dijkstra:   Dijkstra.swf

Chapter5: Data Link Layer
	LAN examples:  LAN examples.htm

